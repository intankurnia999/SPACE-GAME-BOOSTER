package com.spacegamebooster.app

import android.app.Service
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PixelFormat
import android.os.IBinder
import android.view.Gravity
import android.view.View
import android.view.WindowManager

class CrosshairService : Service() {
    private lateinit var wm: WindowManager
    private var crosshair: CrosshairView? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        crosshair = CrosshairView()
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        )
        params.gravity = Gravity.TOP or Gravity.START
        wm.addView(crosshair, params)
    }

    override fun onDestroy() {
        crosshair?.let { if (it.isAttachedToWindow) wm.removeView(it) }
        crosshair = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private class CrosshairView : View(null) {
        private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.CYAN
            strokeWidth = 4f
            style = Paint.Style.STROKE
            setShadowLayer(12f, 0f, 0f, Color.MAGENTA)
        }
        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            val x = width / 2f
            val y = height / 2f
            val r = 15f
            canvas.drawCircle(x, y, r, p)
            canvas.drawLine(x - 30, y, x - 19, y, p)
            canvas.drawLine(x + 19, y, x + 30, y, p)
            canvas.drawLine(x, y - 30, x, y - 19, p)
            canvas.drawLine(x, y + 19, x, y + 30, p)
        }
    }
}
