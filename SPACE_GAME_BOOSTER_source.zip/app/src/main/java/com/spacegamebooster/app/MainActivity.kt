package com.spacegamebooster.app

import android.app.Activity
import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.BatteryManager
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.io.RandomAccessFile

class MainActivity : Activity() {
    private lateinit var root: LinearLayout
    private lateinit var infoText: TextView
    private var overlayOn = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(8, 11, 27)
        window.navigationBarColor = Color.rgb(8, 11, 27)
        buildUi()
        refreshInfo()
    }

    private fun buildUi() {
        val scroll = ScrollView(this)
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(24), dp(20), dp(28))
            background = GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                intArrayOf(Color.rgb(8,11,27), Color.rgb(24,13,55), Color.rgb(7,27,48))
            )
        }
        scroll.addView(root)
        setContentView(scroll)

        val title = text("✦ SPACE GAME BOOSTER ✦", 24, Color.CYAN, true)
        title.gravity = Gravity.CENTER
        root.addView(title, params())
        val sub = text("GAMING CONTROL CENTER  •  ANDROID 11", 11, Color.LTGRAY, true)
        sub.gravity = Gravity.CENTER
        root.addView(sub, params(0, 18))

        val hero = text("READY FOR YOUR NEXT MATCH?", 17, Color.WHITE, true)
        hero.gravity = Gravity.CENTER
        hero.background = panel()
        hero.setPadding(dp(14), dp(20), dp(14), dp(20))
        root.addView(hero, params(0, 18))

        section("TOOLS")
        addButton("🎯  CROSSHAIR OVERLAY", "Tampilkan / sembunyikan crosshair di layar") { toggleCrosshair() }
        addButton("⚡  GAME MODE", "Mode praktis: layar penuh dan pintasan pengaturan") {
            window.decorView.systemUiVisibility =
                View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
            Toast.makeText(this, "Mode layar penuh aktif. Ketuk area bawah/atas untuk menampilkan navigasi.", Toast.LENGTH_LONG).show()
        }
        addButton("🎮  SENSITIVITY NOTES", "Catatan sensitivitas manual untuk Free Fire") {
            showMessage("Sensitivitas Free Fire diatur dari dalam game. Mulai dari nilai bawaan, lalu sesuaikan bertahap sesuai kenyamanan. Aplikasi ini tidak mengubah file atau memori game.")
        }
        addButton("🎙️  VOICE CHANGER", "Perangkat Android biasanya membatasi efek suara lintas aplikasi") {
            showMessage("Pengubah suara sistem-wide saat bermain tidak disediakan karena Android 11 membatasi pemrosesan mikrofon aplikasi lain. Gunakan fitur voice effect bawaan game/perangkat jika tersedia.")
        }

        section("DEVICE MONITOR")
        infoText = text("Memuat informasi perangkat…", 14, Color.WHITE, false)
        infoText.background = panel()
        infoText.setPadding(dp(16), dp(14), dp(16), dp(14))
        root.addView(infoText, params(0, 8))
        addButton("↻  REFRESH DEVICE INFO", "Perbarui RAM, baterai, CPU, dan versi Android") { refreshInfo() }
        addButton("🧹  MEMORY STATUS", "Lihat kondisi memori; Android mengelola RAM otomatis") {
            refreshInfo()
            showMessage("Android mengelola RAM secara otomatis. Aplikasi ini tidak mematikan proses aplikasi lain secara paksa karena dapat membuat sistem lebih lambat atau tidak stabil.")
        }
        addButton("🖥️  GPU / FPS INFO", "Lihat batas pemantauan GPU dan FPS Android") {
            showMessage("GPU: " + gpuSummary() + "\nFPS game lain tidak dapat dibaca secara akurat oleh aplikasi biasa di Android 11 tanpa akses khusus. Gunakan penghitung FPS bawaan game/perangkat jika tersedia.")
        }

        val footer = text("SAFE MODE • NO GAME INJECTION • NO CHEATS", 10, Color.LTGRAY, true)
        footer.gravity = Gravity.CENTER
        root.addView(footer, params(0, 20))
    }

    private fun toggleCrosshair() {
        if (overlayOn) {
            stopService(Intent(this, CrosshairService::class.java))
            overlayOn = false
            Toast.makeText(this, "Crosshair dimatikan", Toast.LENGTH_SHORT).show()
        } else if (Settings.canDrawOverlays(this)) {
            startService(Intent(this, CrosshairService::class.java))
            overlayOn = true
            Toast.makeText(this, "Crosshair aktif", Toast.LENGTH_SHORT).show()
        } else {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            Toast.makeText(this, "Izinkan tampil di atas aplikasi lain, lalu kembali ke sini.", Toast.LENGTH_LONG).show()
        }
    }

    private fun refreshInfo() {
        if (!::infoText.isInitialized) return
        val am = getSystemService(ACTIVITY_SERVICE) as ActivityManager
        val mi = ActivityManager.MemoryInfo()
        am.getMemoryInfo(mi)
        val total = mi.totalMem / (1024 * 1024)
        val available = mi.availMem / (1024 * 1024)
        val used = total - available
        val bm = getSystemService(Context.BATTERY_SERVICE) as BatteryManager
        val battery = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
        val cpu = try {
            RandomAccessFile("/proc/cpuinfo", "r").use { it.readLine() ?: "Tidak tersedia" }
        } catch (_: Exception) { "Tidak tersedia" }
        infoText.text = "DEVICE  •  ${Build.MANUFACTURER} ${Build.MODEL}\n" +
            "ANDROID  •  ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})\n" +
            "RAM  •  ${used} MB digunakan / ${total} MB total\n" +
            "RAM AVAILABLE  •  ${available} MB\n" +
            "BATTERY  •  ${if (battery >= 0) "$battery%" else "Tidak tersedia"}\n" +
            "CPU INFO  •  ${cpu.take(95)}\n" +
            "FPS  •  Tidak tersedia untuk aplikasi game lain"
    }

    private fun gpuSummary(): String =
        "Renderer GPU tidak dapat dibaca universal tanpa konteks OpenGL aktif. Periksa spesifikasi perangkat atau aplikasi info perangkat tepercaya."

    private fun addButton(label: String, detail: String, action: () -> Unit) {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = panel()
            setPadding(dp(15), dp(13), dp(15), dp(13))
        }
        val b = text(label, 15, Color.CYAN, true)
        val d = text(detail, 11, Color.LTGRAY, false)
        box.addView(b)
        box.addView(d)
        box.setOnClickListener { action() }
        root.addView(box, params(0, 9))
    }

    private fun section(s: String) {
        val t = text(s, 12, Color.MAGENTA, true)
        t.setPadding(dp(2), dp(14), 0, dp(8))
        root.addView(t, params())
    }

    private fun text(s: String, size: Int, color: Int, bold: Boolean): TextView =
        TextView(this).apply {
            text = s
            textSize = size.toFloat()
            setTextColor(color)
            if (bold) typeface = Typeface.DEFAULT_BOLD
        }

    private fun panel() = GradientDrawable().apply {
        setColor(Color.argb(150, 19, 29, 62))
        cornerRadius = dp(16).toFloat()
        setStroke(dp(1), Color.argb(180, 48, 190, 255))
    }

    private fun params(top: Int = 0, bottom: Int = 0) =
        LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply {
            topMargin = dp(top)
            bottomMargin = dp(bottom)
        }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun showMessage(msg: String) {
        android.app.AlertDialog.Builder(this)
            .setTitle("SPACE GAME BOOSTER")
            .setMessage(msg)
            .setPositiveButton("OK", null)
            .show()
    }
}
