# SPACE GAME BOOSTER

Proyek Android native (Kotlin) dengan tema space neon, ditujukan untuk Android 11 dan perangkat seperti VIVO Y19.

## Fitur yang sudah ada
- Dashboard neon.
- Crosshair overlay kustom (memerlukan izin "Tampil di atas aplikasi lain").
- Mode layar penuh.
- Informasi model perangkat, versi Android, RAM tersedia/terpakai, dan baterai.
- Catatan sensitivitas Free Fire (manual, tidak mengubah file game).
- Penjelasan batasan FPS dan voice changer.

## Batasan Android
- Aplikasi biasa tidak bisa membersihkan RAM dengan aman dengan mematikan proses aplikasi lain. Android mengelola memori sendiri.
- Android 11 tidak memberi aplikasi biasa akses untuk membaca FPS game lain secara universal.
- Pengubah suara system-wide saat bermain umumnya memerlukan dukungan sistem/vendor atau integrasi khusus.
- GPU renderer tidak bisa diperoleh secara universal dari luar konteks grafis aplikasi.
- Crosshair adalah overlay visual saja; bukan aim assist, tidak membaca game, dan mungkin dilarang oleh aturan beberapa game. Matikan jika game melarang overlay.

## Cara membuka dan membangun APK
1. Instal Android Studio di komputer.
2. Pilih **Open** lalu pilih folder `SPACE_GAME_BOOSTER`.
3. Tunggu Gradle Sync selesai.
4. Jika Android Studio meminta SDK, instal Android SDK Platform 35 dan Build Tools yang disarankan.
5. Pilih **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
6. APK debug biasanya muncul di `app/build/outputs/apk/debug/app-debug.apk`.

## Catatan
Target SDK 30 dipakai agar perilaku izin overlay sesuai Android 11. Untuk rilis publik, tingkatkan target SDK dan uji ulang semua izin serta kebijakan Google Play.
